#!/bin/bash
clear
echo
echo "Tunggu Sampai Proses Selesai Tod Sabar..!"
echo "Ucapkan PAK CYBER  404 Ganteng 3X Biar Work Xixixi:v"
echo
pip install requests
clear
echo
echo "Tunggu Sampai Proses Selesai Tod Sabar..!"
echo "Ucapkan PAK CYBER  404 Ganteng 3X Biar Work Xixixi:v"
echo
pip install mechanize
clear
echo
echo "Tunggu Sampai Proses Selesai Tod Sabar..!"
echo "Ucapkan PAK CYBER  404 Ganteng 3X Biar Work Xixixi:v"
echo
pip install requests bs4
clear
echo
echo "Tunggu Sampai Proses Selesai Tod Sabar..!"
echo "Ucapkan PAK CYBER  404 Ganteng 3X Biar Work Xixixi:v"
echo
pkg install figlet
clear
echo
echo "Tunggu Sampai Proses Selesai Tod Sabar..!"
echo "Ucapkan PAK CYBER  404 Ganteng 3X Biar Work Xixixi:v"
echo
pip2 install requests
clear
echo
echo "Tunggu Sampai Proses Selesai Tod Sabar..!"
echo "Ucapkan PAK CYBER  404 Ganteng 3X Biar Work Xixixi:v"
echo
pip2 install tqdm
clear
echo
echo "Tunggu Sampai Proses Selesai Tod Sabar..!"
echo "Ucapkan PAK CYBER  404 Ganteng 3X Biar Work Xixixi:v"
echo
pip2 install mechanize
clear
echo
echo "Tunggu Sampai Proses Selesai Tod Sabar..!"
echo "Ucapkan PAK CYBER  404 Ganteng 3X Biar Work Xixixi:v"
echo
pkg install ruby -y
clear
echo
echo "Tunggu Sampai Proses Selesai Tod Sabar..!"
echo "Ucapkan PAK CYBER  404 Ganteng 3X Biar Work Xixixi:v"
echo
gem install lolcat
clear
figlet EROR 404 | lolcat
sleep 2
clear
figlet EROR 404 | lolcat
sleep 2
clear
echo
echo "╭╮╮╱▔▔▔▔╲╭╭╮╭╮╮╱▔▔▔▔╲╭╭╮╭╮╮╱▔▔▔▔╲╭╭╮" | lolcat
echo "╰╲╲▏▂╲╱▂▕╱╱╯╰╲╲▏▂╲╱▂▕╱╱╯╰╲╲▏▂╲╱▂▕╱╱╯" | lolcat
echo "┈┈╲▏▇▏▕▇▕╱┈┈┈┈╲▏▇▏▕▇▕╱┈┈┈┈╲▏▇▏▕▇▕╱┈┈" | lolcat
echo "┈┈╱╲▔▕▍▔╱╲┈┈┈┈╱╲▔▕▍▔╱╲┈┈┈┈╱╲▔▕▍▔╱╲┈┈" | lolcat
echo "╭╱╱▕╋╋╋╋▏╲╲╮╭╱╱▕╋╋╋╋▏╲╲╮╭╱╱▕╋╋╋╋▏╲╲╮" | lolcat
echo "╰╯╯┈╲▂▂╱┈╰╰╯╰╯╯┈╲▂▂╱┈╰╰╯╰╯╯┈╲▂▂╱┈╰╰╯" | lolcat
echo
echo
echo "ENTER BRO python2 CyBeR.py" | lolcat
