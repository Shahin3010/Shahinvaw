#CYBER ERROR 404

☞︎︎︎ pkg update && pkg upgrade

☞︎︎︎ pkg install python2

☞︎︎︎ pkg install git

☞︎︎︎ pkg install php

☞︎︎︎ pip2 install requests

☞︎︎︎ pip2 install mechanize

☞︎︎︎ pip install lolcat

☞︎︎︎ git clone https://github.com/PAK-CYBER-404/CyBeR

☞︎︎︎ cd CyBeR

☞︎︎︎ bash setup.sh

☞︎︎︎ python2 CyBeR.py

